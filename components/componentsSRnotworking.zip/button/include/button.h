#ifndef _H_BUTTON
#define _H_BUTTON
/// 宏定义
#include "mdf_err.h"

mdf_err_t  test_button_init(void);
int button_press(void);

#endif //_H_BUTTON
